<!DOCTYPE html>
<html>
<head>
	<title>Login</title>
</head>
<body>
<?php 
if(isset($_POST['user']) && isset($_POST['pass']))
{
	$user = $_POST['user'];
	$pass = $_POST['pass'];
	if($user!='' && $pass != '')
	{
		$host = 'localhost';
		$login = 'root';
		$passlog = '';
		$dbname = 'test';
		$port = 3306;		
		$conn = new mysqli($host, $login, $passlog, $dbname, $port);
		if(!$conn)
			die($conn->error_connect);

		$sql = "Select * From account where un='" . $user 
				. "' and pw='" . $pass . "'";
		echo $sql;
		$result = $conn->query($sql);
		if(!$result)
			die($conn->error);
		if(count(mysqli_fetch_all($result))>0)
			echo "<h1>Login successfully!!!</h1>";
		else
			echo "<h1>Login failed!!!</h1>";
	}
	else
	{
		echo "<h1>username and password must be not null</h1>";
	}
}
?>
<form action="" method="post">
	<table>
		<tr>
			<td>User name:</td>
			<td><input type="text" name="user"></td>
		</tr>
		<tr>
			<td>Password: </td>
			<td><input type="text" name="pass"></td>
		</tr>
		<tr>
			<td></td>
			<td>
				<input type="submit" value="Login">
				<input type="reset" value="Reset">
			</td>
		</tr>
	</table>
</form>
</body>
</html>