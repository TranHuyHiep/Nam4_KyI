<!DOCTYPE html>
<html>
<head>
	<title>Login</title>
</head>
<body>

<form action="confirm.php" method="GET">
	<table>
		<tr>
			<td>User name:</td>
			<td><input type="text" name="user"></td>
		</tr>
		<tr>
			<td>Email: </td>
			<td><input type="text" name="email"></td>
		</tr>
		<tr>
			<td></td>
			<td>
				<input type="submit" value="Submit">
				<input type="reset" value="Reset">
			</td>
		</tr>
	</table>
</form>
</body>
</html>