<!DOCTYPE html>
<html>
<head>
	<title>Login</title>
</head>
<body>
<?php 
if(isset($_POST['user']) && isset($_POST['pass']))
{
	$hostname = 'localhost';
	$username = 'root';
	$password = '';
	$dbname = 'test';
	$port = 3306;	
	$user = $_POST['user'];
	$pass = $_POST['pass'];
	if($user!='' && $pass != '')
	{
		$conn = new mysqli($hostname, $username, $password, $dbname, $port);	
		if($conn->connect_error)
			die($conn->connect_error);		
		$sql = "Select * From account where un=? and pw=?";
		$stm = $conn->prepare($sql);
		$stm->bind_param('ss', $user, $pass);
		if($stm->execute()){
            $result = $stm->get_result();
            $num_rows = $result->num_rows;
        }
		if($num_rows > 0){
           	echo "thành công";
		}else{
			echo "thất bại";
		}
	}
	else
	{
		echo "<h1>username and password must be not null</h1>";
	}
}
?>
<form action="" method="post">
	<table>
		<tr>
			<td>User name:</td>
			<td><input type="text" name="user"></td>
		</tr>
		<tr>
			<td>Password: </td>
			<td><input type="text" name="pass"></td>
		</tr>
		<tr>
			<td></td>
			<td>
				<input type="submit" value="Login">
				<input type="reset" value="Reset">
			</td>
		</tr>
	</table>
</form>
</body>
</html>