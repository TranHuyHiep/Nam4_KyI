<?php 

if(isset($_POST['add'])) 
{
	$name = $_POST['name'];
	if($_FILES)
	{
		$image = $_FILES['image']['name'];
		$path = "images/" . $image;
		move_uploaded_file($_FILES['image']['tmp_name'], $path);
	}
    //thêm vào csdl
}
?>
<form action="" method="post" enctype="multipart/form-data">
	<table border="1" cellspacing="0" width="100%" class="table">
		<tr>
			<th colspan="2">Add new product</td>
		</tr>
		
		<tr>
			<td class="col1">Product name: </td>
			<td class="col2"><input type="text" name="name" id="fname" value=""></td>
		</tr>
		<tr>
			<td class="col1">Product image: </td>
			<td class="col2"><input type="file" name="image" id="image"></td>
		</tr>
		
		
		<tr>
			<td class="col1"></td>
			<td class="col2"><input type="submit" value="Save" name="add"></td>
		</tr>
	</table>
</form>