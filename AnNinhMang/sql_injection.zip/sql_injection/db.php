<?php 
class db{
	private $hostname = 'localhost';
	private $username = 'root';
	private $password = '';
	private $dbname = 'test';
	private $port = 3306;
	
	public function fetch_all_assoc($sql)
	{
		$conn = new mysqli($this->hostname, $this->username, $this->password, $this->dbname, $this->port);
		// if($conn->connect_error)
		// 	die($conn->connect_error);
		mysqli_set_charset($conn, 'UTF8');
		$result = $conn->query($sql);
		if(!$result)
			die($conn->error);
		$conn->close();

		$rows = array();
		while ($row = $result->fetch_assoc()) {
		    $rows[] = $row;
		}

		return $rows;
	}
	public function fetch_all_num($sql)
	{
		$conn = new mysqli($this->hostname, $this->username, $this->password, $this->dbname, $this->port);

		if($conn->connect_error)
			die($conn->connect_error);
		mysqli_set_charset($conn, 'UTF8');
		$result = $conn->query($sql);
		if(!$result)
			die($conn->error);
		$conn->close();
		return mysqli_fetch_all($result, MYSQLI_NUM);
	}
	public function exec_query($sql)
	{
		$conn = new mysqli($this->hostname, $this->username, $this->password, $this->dbname, $this->port);
		if($conn->connect_error)
			die($conn->connect_error);
		mysqli_set_charset($conn, 'UTF8');
		$result = $conn->query($sql);
		if(!$result)
			die($conn->error);
		$conn->close();
		return $result;
	}
	public function exec_query_param($sql, & $param_type, & $param)
	{
		$conn = new mysqli($this->hostname, $this->username, $this->password, $this->dbname, $this->port);
		if($conn->connect_error)
			die($conn->connect_error);
		mysqli_set_charset($conn, 'UTF8');
		$stm = $conn->prepare($sql);
				
		$a_params[] = & $param_type;
		 
		for($i = 0; $i < count($param); $i++)   
		  $a_params[] = & $param[$i];
				 
		call_user_func_array(array($stm, 'bind_param'), $a_params);
 

		$result = $stm->execute();
		if(!$result)
			die($conn->error);
		$stm->close();
		$conn->close();
		return $result;
	}
}
?>