<!DOCTYPE html>
<html>
<head>
	<title>Confirm</title>
</head>
<body>
<?php 
if(isset($_GET['user']) && isset($_GET['email']))
{
	$user = $_GET['user'];
	$email = $_GET['email'];
	echo $user;
	if($user!='' && $email != '')
	{
		?>
		<h1>Thanks <?=$user?> for registration</h1>
		<?php
	}
	else
		echo "<h1>Please input full infor!!!</h1>";
}
?>

</body>
</html>